# tijori
Tijori is a Python library that scrapes financial data from Tijori Finance and formats it for seamless analysis with large language models (LLMs). It enables users to efficiently extract, process, and utilize financial information to support data-driven insights and decision-making.
